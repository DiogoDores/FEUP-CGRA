/**
* MyCylinder
* @constructor
*/
function MyCylinder(scene, slices, stacks) {
    CGFobject.call(this, scene);

    this.slices = slices;
    this.stacks = stacks;

    this.initBuffers();
}
;MyCylinder.prototype = Object.create(CGFobject.prototype);
MyCylinder.prototype.constructor = MyCylinder;

MyCylinder.prototype.initBuffers = function() {

    this.vertices = [];
    this.indices = [];
    this.normals = [];

    var internalAngle = (Math.PI * 2) / this.slices;

    for (var j = 0; j < this.stacks; j++) {
        for (var i = 0; i < this.slices; i++) {

            //Base
            this.vertices.push(Math.cos(i * internalAngle));
            this.vertices.push(Math.sin(i * internalAngle));
            this.vertices.push(j/this.stacks);

            //Repetições de modo a fazer as normais
            this.vertices.push(Math.cos((i + 1) * internalAngle));
            this.vertices.push(Math.sin((i + 1) * internalAngle));
            this.vertices.push(j/this.stacks);

            //Topo
            this.vertices.push(Math.cos(i * internalAngle));
            this.vertices.push(Math.sin(i * internalAngle));
            this.vertices.push(j/this.stacks + 1/this.stacks);

            this.vertices.push(Math.cos((i + 1) * internalAngle));
            this.vertices.push(Math.sin((i + 1) * internalAngle));
            this.vertices.push(j/this.stacks+1/this.stacks);

            //Faces exteriores
            this.indices.push(this.slices * 4 * j + 4 * i);
            this.indices.push(this.slices * 4 * j + 4 * i + 1);
            this.indices.push(this.slices * 4 * j + 4 * i + 2);

            this.indices.push(this.slices * 4 * j + 4 * i + 3);
            this.indices.push(this.slices * 4 * j + 4 * i + 2);
            this.indices.push(this.slices * 4 * j + 4 * i + 1);

            this.normals.push(Math.cos(internalAngle * (i + 0.5)));
            this.normals.push(Math.sin(internalAngle * (i + 0.5)));
            this.normals.push(0);

            this.normals.push(Math.cos(internalAngle * (i + 0.5)));
            this.normals.push(Math.sin(internalAngle * (i + 0.5)));
            this.normals.push(0);

            this.normals.push(Math.cos(internalAngle * (i + 0.5)));
            this.normals.push(Math.sin(internalAngle * (i + 0.5)));
            this.normals.push(0);

            this.normals.push(Math.cos(internalAngle * (i + 0.5)));
            this.normals.push(Math.sin(internalAngle * (i + 0.5)));
            this.normals.push(0);
        }
    }

    this.primitiveType = this.scene.gl.TRIANGLES;
    this.initGLBuffers();
}
;
