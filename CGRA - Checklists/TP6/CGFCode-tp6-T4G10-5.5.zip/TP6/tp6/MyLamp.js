/**
* MyLamp
* @constructor
*/
function MyLamp(scene, slices, stacks) {
    CGFobject.call(this, scene);

    this.slices = slices;
    this.stacks = stacks;
    this.slicesAngle = Math.PI * 2 / slices;
    this.stacksAngle = Math.PI / 2 / stacks;
    this.initBuffers();
}
MyLamp.prototype = Object.create(CGFobject.prototype);
MyLamp.prototype.constructor = MyLamp;

MyLamp.prototype.initBuffers = function() {

    this.vertices = [];
    this.indices = [];
    this.normals = [];
    this.texCoords = [];

    for (i = 0; i < this.slices; i++) {
        for (j = 0; j < this.stacks; j++) {
            var x, y, z;
            x = Math.sin(this.stacksAngle * (this.stacks - j)) * Math.cos(this.slicesAngle * i);
            y = Math.sin(this.stacksAngle * (this.stacks - j)) * Math.sin(this.slicesAngle * i);
            z = Math.cos(this.stacksAngle * (this.stacks - j));

            this.vertices.push(x, y, z);
            this.normals.push(x, y, z);
        }
    }

    this.vertices.push(0, 0, 1);
    this.normals.push(0, 0, 1);

    for (i = 0; i < this.slices; i++) {
        for (j = 0; j < this.stacks - 1; j++) {
            this.indices.push(i % this.slices * this.stacks + j);
            this.indices.push((i + 1) % this.slices * this.stacks + j);
            this.indices.push((i + 1) % this.slices * this.stacks + j + 1);

            this.indices.push(i % this.slices * this.stacks + j);
            this.indices.push((i + 1) % this.slices * this.stacks + j + 1);
            this.indices.push(i % this.slices * this.stacks + j + 1);
        }
    }

    var topVertex = this.vertices.length / 3 - 1;

    for (i = 0; i < this.slices; i++) {
        this.indices.push(i % this.slices * this.stacks + this.stacks - 1);
        this.indices.push((i + 1) % this.slices * this.stacks + this.stacks - 1);
        this.indices.push(topVertex);
    }

    var s = 0;
	var t = 0;
	var sinc = 1/this.slices;
	var tinc = 1/this.stacks;
	for (var a = 0; a <= this.stacks; a++) {
		for (var b = 0; b < this.slices; b++) {
			this.texCoords.push(s, t);
			s += sinc;
		}
		s = 0;
		t += tinc;
	}

    this.primitiveType = this.scene.gl.TRIANGLES;
    this.initGLBuffers();
}
